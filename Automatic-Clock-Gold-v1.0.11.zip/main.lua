-- Automatic Clock for Pokemon Gold / Gen 2 recomp.
--
-- The recomp already uses the host OS clock as its RTC source. Gold normally
-- adds offsets to that clock after the player manually answers Oak and Mom.
-- This mod keeps those offsets at zero, making the device clock authoritative,
-- and removes the now-redundant setup UI from a new game.

return function(mod)
  local Clock = require("src.core.gen2.Clock")

  local function syncToHost(save)
    if type(save) ~= "table" then return save end
    save.rtc = save.rtc or {}

    -- Zero offsets keep Gold tied directly to the host device clock.
    save.rtc.startMinute = 0
    save.rtc.startDay = 0
    save.rtc.dayOfWeek = Clock.hostWeekday()
    save.rtc.day = tonumber(os.date("%j")) or save.rtc.day

    -- The operating system already handles daylight-saving time.
    save.rtc.dst = false
    return save
  end

  mod.hooks:wrap("save.new_game", function(next, save)
    local out = next(save)
    return syncToHost(out)
  end)

  -- Remove Oak's opening manual clock setup beat.
  mod.hooks:wrap("intro.oak_speech.build", function(next, steps, speech)
    steps = next(steps, speech)
    if type(steps) ~= "table" then return steps end

    local game = speech and speech.game
    syncToHost(game and game.save)

    for i = #steps, 1, -1 do
      if steps[i] and steps[i].id == "init_clock" then
        table.remove(steps, i)
      end
    end
    return steps
  end)

  -- Mom's Pokegear scene.  Do not key this to a guessed map id: the extracted
  -- script gives us a much stronger signature. `getstring PokegearName` loads
  -- "#GEAR", and the same scene later executes addcellnum PHONE_MOM.
  local momScene = setmetatable({}, { __mode = "k" })

  local function vmSave(vm)
    return vm and vm.specials and vm.specials.save and vm.specials.save()
  end

  local function restartMapMusic(vm)
    if not (vm and vm.specialOrder) then return end
    for i, specialName in ipairs(vm.specialOrder) do
      if specialName == "RestartMapMusic" then
        vm:runSpecial(i - 1, {})
        return
      end
    end
  end

  local function movementKeyFor(vm, wanted)
    if not (vm and vm.movements) then return nil end
    for key, bytes in pairs(vm.movements) do
      if type(bytes) == "table" and #bytes == #wanted then
        local same = true
        for i = 1, #wanted do
          if bytes[i] ~= wanted[i] then
            same = false
            break
          end
        end
        if same then return key end
      end
    end
    return nil
  end

  mod.hooks:wrap("script.command", function(next, ctx, name, args, cmd)
    if not (ctx and ctx.generation == 2 and ctx.vm) then
      return next(ctx, name, args, cmd)
    end

    local vm = ctx.vm
    local state = momScene[vm]

    -- PokegearName is an extracted literal ("#GEAR"), not a text pointer.
    if name == "getstring" and cmd and type(cmd.string) == "string"
        and cmd.string:upper():find("GEAR", 1, true) then
      momScene[vm] = "await_phone"
      return next(ctx, name, args, cmd)
    end

    -- This happens after the receive-item standard script and before
    -- MomGivesPokegearText.
    if state == "await_phone" and name == "addcellnum" then
      momScene[vm] = "replace_mom_text"
      return next(ctx, name, args, cmd)
    end

    if state == "replace_mom_text" and name == "writetext" and cmd then
      -- Use a temporary text resource and let the vanilla writetext command
      -- display it. This keeps textbox lifecycle exactly the same as Gold.
      local key = "__automatic_clock_mom_sendoff"
      vm.text[key] = "Now, don't keep PROF. ELM waiting!"
      local replacement = {}
      for k, v in pairs(cmd) do replacement[k] = v end
      replacement.text = key

      momScene[vm] = "await_set_day"
      return next(ctx, name, args, replacement)
    end

    if state == "await_set_day" and name == "special" and cmd
        and vm:specialName(cmd.id) == "SetDayOfWeek" then
      syncToHost(vmSave(vm))
      momScene[vm] = "skip_tutorial_tail"
      return nil
    end

    if state == "skip_tutorial_tail" then
      -- Suppress the obsolete weekday/DST/phone tutorial text.
      if name == "writetext" then
        return nil
      end

      -- Never open the old Yes/No menus. Treat them as YES internally so the
      -- original branch structure takes its shortest path to .FinishPhone.
      if name == "yesorno" then
        vm.scriptVar = 1
        return nil
      end

      if name == "special" and cmd then
        local specialName = vm:specialName(cmd.id)
        if specialName == "InitialSetDSTFlag"
            or specialName == "InitialClearDSTFlag"
            or specialName == "SetDayOfWeek" then
          syncToHost(vmSave(vm))
          return nil
        end
      end

      if name == "promptbutton" or name == "waitbutton" then
        return nil
      end

      -- Resume vanilla Gold at closetext. The cart then checks which entrance
      -- trigger started Mom's scene and runs its own MomTurnsBackMovement or
      -- MomWalksBackMovement, followed by RestartMapMusic and her final facing.
      if name == "closetext" then
        momScene[vm] = nil
        return next(ctx, name, args, cmd)
      end
    end

    return next(ctx, name, args, cmd)
  end)

  mod.log:info("Automatic Clock enabled: Gold follows the host device date/time")
end
