# Automatic Clock — Gold

Uses the host phone/PC date and time for Pokémon Gold and streamlines the
opening Pokégear scene.

## v1.0.11

Fixes Mom remaining in front of the player after the streamlined Pokégear
dialogue.

The mod no longer tries to reconstruct or manually invoke Mom's return
movement. It suppresses only the obsolete weekday, DST, and Pokégear tutorial
portion. At the original `closetext`, control is handed back to Gold's own
`MeetMomScript`.

Gold then executes its original ending exactly:
- checks which Mom encounter trigger was used
- chooses `MomTurnsBackMovement` or `MomWalksBackMovement`
- restores the map music
- turns Mom left
- ends the scene

The short `Now, don't keep PROF. ELM waiting!` dialogue and automatic device
clock behavior are unchanged.
